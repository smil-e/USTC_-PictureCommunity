package _response

/*评论*/
type ResComment struct {
	Nickname    string
	Profile     string
	Like_number int
	Content     string
}

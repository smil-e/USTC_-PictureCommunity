# Summary

Date : 2022-06-19 23:35:17

Directory /home/ch/PictureCommunity

Total : 87 files,  3418 codes, 0 comments, 558 blanks, all 3976 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Go | 85 | 3,316 | 0 | 553 | 3,869 |
| Go Checksum File | 1 | 73 | 0 | 1 | 74 |
| Go Module File | 1 | 29 | 0 | 4 | 33 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 87 | 3,418 | 0 | 558 | 3,976 |
| controller | 16 | 993 | 0 | 145 | 1,138 |
| dao | 10 | 639 | 0 | 95 | 734 |
| dao/firstpage | 2 | 143 | 0 | 14 | 157 |
| dao/post | 4 | 283 | 0 | 39 | 322 |
| dao/user | 4 | 213 | 0 | 42 | 255 |
| entity | 34 | 435 | 0 | 101 | 536 |
| entity/_request | 13 | 129 | 0 | 38 | 167 |
| entity/_response | 9 | 157 | 0 | 27 | 184 |
| entity/db | 12 | 149 | 0 | 36 | 185 |
| global | 1 | 21 | 0 | 7 | 28 |
| initialize | 3 | 57 | 0 | 13 | 70 |
| middleware | 1 | 31 | 0 | 5 | 36 |
| response | 2 | 49 | 0 | 13 | 62 |
| router | 1 | 90 | 0 | 10 | 100 |
| service | 13 | 868 | 0 | 143 | 1,011 |
| utils | 3 | 119 | 0 | 18 | 137 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)
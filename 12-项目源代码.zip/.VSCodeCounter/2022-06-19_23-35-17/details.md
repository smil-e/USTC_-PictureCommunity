# Details

Date : 2022-06-19 23:35:17

Directory /home/ch/PictureCommunity

Total : 87 files,  3418 codes, 0 comments, 558 blanks, all 3976 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [controller/CollectionController.go](/controller/CollectionController.go) | Go | 51 | 0 | 4 | 55 |
| [controller/CommentController.go](/controller/CommentController.go) | Go | 94 | 0 | 8 | 102 |
| [controller/FileController.go](/controller/FileController.go) | Go | 16 | 0 | 4 | 20 |
| [controller/FollowUserController.go](/controller/FollowUserController.go) | Go | 27 | 0 | 5 | 32 |
| [controller/LikeController.go](/controller/LikeController.go) | Go | 53 | 0 | 4 | 57 |
| [controller/MessageController.go](/controller/MessageController.go) | Go | 59 | 0 | 10 | 69 |
| [controller/PostController.go](/controller/PostController.go) | Go | 51 | 0 | 8 | 59 |
| [controller/RegisterController.go](/controller/RegisterController.go) | Go | 35 | 0 | 5 | 40 |
| [controller/SearchController.go](/controller/SearchController.go) | Go | 24 | 0 | 6 | 30 |
| [controller/UserInfo.go](/controller/UserInfo.go) | Go | 58 | 0 | 12 | 70 |
| [controller/WebSocketController.go](/controller/WebSocketController.go) | Go | 169 | 0 | 24 | 193 |
| [controller/firstpageController.go](/controller/firstpageController.go) | Go | 63 | 0 | 4 | 67 |
| [controller/login.go](/controller/login.go) | Go | 38 | 0 | 7 | 45 |
| [controller/testGetToken.go](/controller/testGetToken.go) | Go | 14 | 0 | 3 | 17 |
| [controller/userHomeController.go](/controller/userHomeController.go) | Go | 109 | 0 | 26 | 135 |
| [controller/userInfoController.go](/controller/userInfoController.go) | Go | 132 | 0 | 15 | 147 |
| [dao/firstpage/getById.go](/dao/firstpage/getById.go) | Go | 48 | 0 | 5 | 53 |
| [dao/firstpage/getDetail.go](/dao/firstpage/getDetail.go) | Go | 95 | 0 | 9 | 104 |
| [dao/post/Comment.go](/dao/post/Comment.go) | Go | 129 | 0 | 14 | 143 |
| [dao/post/collection.go](/dao/post/collection.go) | Go | 52 | 0 | 9 | 61 |
| [dao/post/like.go](/dao/post/like.go) | Go | 60 | 0 | 9 | 69 |
| [dao/post/select.go](/dao/post/select.go) | Go | 42 | 0 | 7 | 49 |
| [dao/user/insert.go](/dao/user/insert.go) | Go | 24 | 0 | 5 | 29 |
| [dao/user/query.go](/dao/user/query.go) | Go | 54 | 0 | 12 | 66 |
| [dao/user/select.go](/dao/user/select.go) | Go | 115 | 0 | 19 | 134 |
| [dao/user/update.go](/dao/user/update.go) | Go | 20 | 0 | 6 | 26 |
| [entity/_request/Comment.go](/entity/_request/Comment.go) | Go | 24 | 0 | 3 | 27 |
| [entity/_request/UserFollow.go](/entity/_request/UserFollow.go) | Go | 4 | 0 | 2 | 6 |
| [entity/_request/collection.go](/entity/_request/collection.go) | Go | 5 | 0 | 2 | 7 |
| [entity/_request/firstpage.go](/entity/_request/firstpage.go) | Go | 8 | 0 | 3 | 11 |
| [entity/_request/like.go](/entity/_request/like.go) | Go | 5 | 0 | 2 | 7 |
| [entity/_request/loginUser.go](/entity/_request/loginUser.go) | Go | 10 | 0 | 3 | 13 |
| [entity/_request/message.go](/entity/_request/message.go) | Go | 5 | 0 | 2 | 7 |
| [entity/_request/post.go](/entity/_request/post.go) | Go | 15 | 0 | 5 | 20 |
| [entity/_request/registerUser.go](/entity/_request/registerUser.go) | Go | 8 | 0 | 3 | 11 |
| [entity/_request/searchUser.go](/entity/_request/searchUser.go) | Go | 6 | 0 | 2 | 8 |
| [entity/_request/updateUser.go](/entity/_request/updateUser.go) | Go | 25 | 0 | 6 | 31 |
| [entity/_request/userHome.go](/entity/_request/userHome.go) | Go | 6 | 0 | 2 | 8 |
| [entity/_request/userInfo.go](/entity/_request/userInfo.go) | Go | 8 | 0 | 3 | 11 |
| [entity/_response/Comment.go](/entity/_response/Comment.go) | Go | 44 | 0 | 7 | 51 |
| [entity/_response/firsrpagePost.go](/entity/_response/firsrpagePost.go) | Go | 33 | 0 | 3 | 36 |
| [entity/_response/loginBackUp.go](/entity/_response/loginBackUp.go) | Go | 4 | 0 | 2 | 6 |
| [entity/_response/message.go](/entity/_response/message.go) | Go | 13 | 0 | 4 | 17 |
| [entity/_response/responseComment.go](/entity/_response/responseComment.go) | Go | 8 | 0 | 2 | 10 |
| [entity/_response/responsePost.go](/entity/_response/responsePost.go) | Go | 11 | 0 | 2 | 13 |
| [entity/_response/responseSearchUsers.go](/entity/_response/responseSearchUsers.go) | Go | 8 | 0 | 2 | 10 |
| [entity/_response/userInfo.go](/entity/_response/userInfo.go) | Go | 27 | 0 | 3 | 30 |
| [entity/_response/userPosts.go](/entity/_response/userPosts.go) | Go | 9 | 0 | 2 | 11 |
| [entity/db/chat.go](/entity/db/chat.go) | Go | 11 | 0 | 3 | 14 |
| [entity/db/collection.go](/entity/db/collection.go) | Go | 10 | 0 | 3 | 13 |
| [entity/db/comment.go](/entity/db/comment.go) | Go | 14 | 0 | 3 | 17 |
| [entity/db/fans.go](/entity/db/fans.go) | Go | 10 | 0 | 3 | 13 |
| [entity/db/follow.go](/entity/db/follow.go) | Go | 10 | 0 | 3 | 13 |
| [entity/db/forward.go](/entity/db/forward.go) | Go | 14 | 0 | 3 | 17 |
| [entity/db/liked.go](/entity/db/liked.go) | Go | 10 | 0 | 3 | 13 |
| [entity/db/post.go](/entity/db/post.go) | Go | 17 | 0 | 3 | 20 |
| [entity/db/post_photo.go](/entity/db/post_photo.go) | Go | 13 | 0 | 3 | 16 |
| [entity/db/user.go](/entity/db/user.go) | Go | 12 | 0 | 3 | 15 |
| [entity/db/user_data.go](/entity/db/user_data.go) | Go | 12 | 0 | 3 | 15 |
| [entity/db/user_detail.go](/entity/db/user_detail.go) | Go | 16 | 0 | 3 | 19 |
| [global/global.go](/global/global.go) | Go | 21 | 0 | 7 | 28 |
| [go.mod](/go.mod) | Go Module File | 29 | 0 | 4 | 33 |
| [go.sum](/go.sum) | Go Checksum File | 73 | 0 | 1 | 74 |
| [initialize/idGeneratorInitialize.go](/initialize/idGeneratorInitialize.go) | Go | 12 | 0 | 3 | 15 |
| [initialize/mysql_connection.go](/initialize/mysql_connection.go) | Go | 29 | 0 | 5 | 34 |
| [initialize/startSystem.go](/initialize/startSystem.go) | Go | 16 | 0 | 5 | 21 |
| [main.go](/main.go) | Go | 14 | 0 | 3 | 17 |
| [middleware/Auth.go](/middleware/Auth.go) | Go | 31 | 0 | 5 | 36 |
| [response/Response.go](/response/Response.go) | Go | 29 | 0 | 10 | 39 |
| [response/ResponseCode.go](/response/ResponseCode.go) | Go | 20 | 0 | 3 | 23 |
| [router/router.go](/router/router.go) | Go | 90 | 0 | 10 | 100 |
| [service/MessageService.go](/service/MessageService.go) | Go | 21 | 0 | 11 | 32 |
| [service/collectionService.go](/service/collectionService.go) | Go | 49 | 0 | 7 | 56 |
| [service/commentService.go](/service/commentService.go) | Go | 75 | 0 | 3 | 78 |
| [service/firstpageService.go](/service/firstpageService.go) | Go | 58 | 0 | 5 | 63 |
| [service/likeService.go](/service/likeService.go) | Go | 46 | 0 | 6 | 52 |
| [service/loginService.go](/service/loginService.go) | Go | 56 | 0 | 10 | 66 |
| [service/post.go](/service/post.go) | Go | 220 | 0 | 27 | 247 |
| [service/registerService.go](/service/registerService.go) | Go | 44 | 0 | 5 | 49 |
| [service/searchService.go](/service/searchService.go) | Go | 15 | 0 | 6 | 21 |
| [service/user.go](/service/user.go) | Go | 124 | 0 | 16 | 140 |
| [service/userDetailService.go](/service/userDetailService.go) | Go | 81 | 0 | 12 | 93 |
| [service/userHomeService.go](/service/userHomeService.go) | Go | 38 | 0 | 26 | 64 |
| [service/userInfo.go](/service/userInfo.go) | Go | 41 | 0 | 9 | 50 |
| [utils/jwt.go](/utils/jwt.go) | Go | 49 | 0 | 7 | 56 |
| [utils/snowFlake.go](/utils/snowFlake.go) | Go | 45 | 0 | 7 | 52 |
| [utils/util.go](/utils/util.go) | Go | 25 | 0 | 4 | 29 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)